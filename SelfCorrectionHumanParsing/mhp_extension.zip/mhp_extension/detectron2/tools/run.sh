python finetune_net.py \
	--config-file ../configs/Misc/parsing_finetune_cihp+vip.yaml \
	--num-gpus 8
